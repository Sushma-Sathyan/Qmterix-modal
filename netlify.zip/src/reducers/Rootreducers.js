import { combineReducers } from 'redux';
import CustomizerReducer from '../redux/customizer/CustomizerReducer';
import registerReducer from './RegisterReducer';
import userLoginReducer from './Authreducer';
import resetPasswordReducer from './reset-password';
import forgotPasswordReducer from './forgotPassword';
import getJiraReducer from './Integration/GetJiraReducers';
import addJiraReducer from './Integration/AddJiraReducers';

const RootReducers = combineReducers({
  userLoginReducer,
  CustomizerReducer,
  registerReducer,
  resetPasswordReducer,
  forgotPasswordReducer,
  getJiraReducer,
  addJiraReducer
});

export default RootReducers;
