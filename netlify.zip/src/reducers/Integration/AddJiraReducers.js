import {FETCH_ADD_JIRA_DETAILS_REQUEST, FETCH_ADD_JIRA_DETAILS_SUCCESS, FETCH_ADD_JIRA_DETAILS_FAILURE} from '../../actions/types';

const initialState = {
    JIRA_BASE_URL: "",
    JIRA_USERNAME: "",
    JIRA_API_TOKEN: "",
    loading: false,
    error: null
};

const addJiraReducer = (state = initialState, action) => {
    switch (action.type) {
      case FETCH_ADD_JIRA_DETAILS_REQUEST:
        return {
          ...state,
          loading: true,
          error: null,
        };
      case FETCH_ADD_JIRA_DETAILS_SUCCESS:
        return {
          ...state,
          loading: false,
          addJira: action.payload,
        };
      case FETCH_ADD_JIRA_DETAILS_FAILURE:
        return {
          ...state,
          loading: false,
          error: action.payload,
        };
      default:
        return state;
    }
  };

  export default addJiraReducer;