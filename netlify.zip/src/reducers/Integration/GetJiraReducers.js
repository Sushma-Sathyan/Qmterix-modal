import {FETCH_JIRA_DETAILS_REQUEST, FETCH_JIRA_DETAILS_SUCCESS, FETCH_JIRA_DETAILS_FAILURE} from '../../actions/types';

const initialState = {
    jiraDetails: [],
    loading: false,
    error: null
};

const getJiraReducer = (state = initialState, action) => {
    switch (action.type) {
      case FETCH_JIRA_DETAILS_REQUEST:
        return {
          ...state,
          loading: true,
          error: null,
        };
      case FETCH_JIRA_DETAILS_SUCCESS:
        return {
          ...state,
          loading: false,
          jiraDetails: action.payload,
        };
      case FETCH_JIRA_DETAILS_FAILURE:
        return {
          ...state,
          loading: false,
          error: action.payload,
        };
      default:
        return state;
    }
  };

  export default getJiraReducer;