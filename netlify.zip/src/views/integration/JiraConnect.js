import Typography from '@mui/material/Typography';
import Breadcrumb from '../../layouts/full-layout/breadcrumb/Breadcrumb';
import PageContainer from '../../components/container/PageContainer';
import { Box, Button, Stack } from '@mui/material';
import BaseCard from '../../components/base-card/BaseCard';
import { PropaneSharp } from '@mui/icons-material';
import Modal from '@mui/material/Modal';
import { Card, CardContent } from '@mui/material';
import { Grid } from '@mui/material';
import CustomTextField from '../../components/forms/custom-elements/CustomTextField';
import CustomFormLabel from '../../components/forms/custom-elements/CustomFormLabel';
import { Link, useNavigate, useLocation } from 'react-router-dom';
import { useDispatch, useSelector } from 'react-redux';
import { toast, ToastContainer } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import * as yup from "yup";
import { useState, useEffect } from 'react';
import { useFormik } from 'formik';
import addJiraDetails from '../../actions/Integration/AddJiraActions';
import RingLoader from 'react-spinners/RingLoader';

export default function JiraConnect(props) {
    const navigate = useNavigate();
    const dispatch = useDispatch();
    const res = useSelector(state => state.addJiraReducer);
    const [initialValues, setInitialValues] = useState({
        JIRA_BASE_URL: "",
        JIRA_USERNAME: "",
        JIRA_API_TOKEN: ""
    });

    const [token, setToken] = useState('');
    const location = useLocation();
    const [loading, setLoading] = useState(false);

    useEffect(() => {
        const params = new URLSearchParams(location.search);
        console.log("PARAMs",params);
        const tokenParam = params.get('token');
        setToken(tokenParam);
    }, [location.search]);

    const validationSchema = yup.object({
        JIRA_BASE_URL: yup.string()
                .url('Invalid URL format')
                .required('Base URL is required'),
        JIRA_USERNAME: yup.string()
                .email('Invalid email address')
                .required('Email is required'),
        JIRA_API_TOKEN: yup.string()
                .required('API Token us required')
    });

    const formik = useFormik({
        initialValues: initialValues,
        enableReinitialize: true,
        validationSchema: validationSchema,
        onSubmit: async (values) => {
            console.log("Submitted!!",token);
            const token2 = localStorage.getItem('qmetrix-token');
            console.log("Token",token2);
            if(values.JIRA_BASE_URL !== '' && values.JIRA_USERNAME !== '' && values.JIRA_API_TOKEN !== ''){
                const payload = {
                    token: token2,
                    JIRA_BASE_URL: values.JIRA_BASE_URL,
                    JIRA_USERNAME: values.JIRA_USERNAME,
                    JIRA_API_TOKEN: values.JIRA_API_TOKEN
                };
                try{
                    setLoading(true);
                    const response = await addJiraDetails(dispatch, payload);
                    if(response.code === '000'){
                        console.log("Success!!");
                        toast.success(`${response.messageText}`);
                        setTimeout(() => {
                            props.onConnection();
                        },4000);
                        // props.onConnection();
                    } else{
                        console.log("****",response.messageText);
                        toast.info(`${response.messageText}`);
                    }
                } catch (error) {
                    console.error('JIRA Connection and Integration Failed',error);
                } finally {
                    setLoading(false);
                }
            }
        }
    })

    const style = {
        position: 'absolute' ,
        top: '50%',
        left: '50%',
        transform: 'translate(-50%, -50%)',
        width: '70vw',
        maxHeight: '90vh',
        bgcolor: 'background.paper',
        // border: '2px solid #000',
        borderRadius: '10px',
        // boxShadow: 24,
        // p:1,
        // paddingLeft: '25px',
        // paddingRight: '25px',
        padding: '10px 20px 10px 20px',
        overflow: 'auto'
      };
      const loaderStyle = {
        position: 'fixed',
        top: '50%',
        left: '50%',
        transform: 'translate(-50%, -50%)',
        zIndex: 9999,
        // backgroundColor: 'rgba(255, 255, 255, 0.8)',
        borderRadius: '10px',
        padding: '20px'
    };
    return(
    <Box sx={style}>
        <form onSubmit={formik.handleSubmit}>
            <Typography id="modal-modal-title" variant="h2" component="h2" alignItems="center" style={{padding: '10px', fontWeight: '800'}}>
                JIRA Integration
            </Typography>
                <Grid container spacing={2} style={{padding: '0px 10px 10px 10px'}}>
                    <Grid item sm={12} lg={12} xs={12}>
                        <CustomFormLabel htmlFor="JIRA_BASE_URL" style={{fontSize: 'large', fontWeight: '700'}} >Base URL</CustomFormLabel>
                        <CustomFormLabel style={{fontSize: 'medium', fontWeight: '400'}}> Get your Jira sitename from your Jira url (e.g. https://[sitename].atlassian.net) and only enter the [sitename] portion
                        </CustomFormLabel>
                        <CustomTextField
                            id="JIRA_BASE_URL"
                            name="JIRA_BASE_URL"
                            placeholder=""
                            variant="outlined"
                            fullWidth
                            size="small"
                            value={formik.values.JIRA_BASE_URL}
                            onChange={formik.handleChange}
                            error={formik.touched.JIRA_BASE_URL && Boolean(formik.errors.JIRA_BASE_URL)}
                            helperText={formik.touched.JIRA_BASE_URL && formik.errors.JIRA_BASE_URL}
                        />
                    </Grid>
        
                    <Grid item sm={12} lg={12} xs={12}>      
                        <CustomFormLabel htmlFor="JIRA_USERNAME" style={{fontSize: 'large', fontWeight: '700'}}>Username</CustomFormLabel>
                        <CustomFormLabel htmlFor="description" style={{fontSize: 'medium', fontWeight: '400'}}>Enter the email address that you use to login into Jira.</CustomFormLabel>
        
                        <CustomTextField
                            id="JIRA_USERNAME"
                            name="JIRA_USERNAME"
                            placeholder=""
                            variant="outlined"
                            fullWidth
                            size="small"
                            value={formik.values.JIRA_USERNAME}
                            onChange={formik.handleChange}
                            error={formik.touched.JIRA_USERNAME && Boolean(formik.errors.JIRA_USERNAME)}
                            helperText={formik.touched.JIRA_USERNAME && formik.errors.JIRA_USERNAME}
                        />
                    </Grid>

                    <Grid item sm={12} lg={12} xs={12}>

                        <CustomFormLabel htmlFor="JIRA_API_TOKEN" style={{fontSize: 'large', fontWeight: '700'}}> API token</CustomFormLabel>
                        <CustomFormLabel style={{fontSize: 'medium', fontWeight: '400'}}> Create an API token (<Link style={{color: 'rgb(3, 201, 215)'}}>See instructions here</Link>) and enter it here.
                        </CustomFormLabel>
                        <CustomTextField
                            id="JIRA_API_TOKEN"
                            name="JIRA_API_TOKEN"
                            variant="outlined"
                            fullWidth
                            multiline={true}
                            size="small"
                            value={formik.values.JIRA_API_TOKEN}
                            onChange={formik.handleChange}
                            error={formik.touched.JIRA_API_TOKEN && Boolean(formik.errors.JIRA_API_TOKEN)}
                            helperText={formik.touched.JIRA_API_TOKEN && formik.errors.JIRA_API_TOKEN}
                        />
      
  
  
 
                    </Grid>
                    <Grid item sm={12} lg={12} xs={12}>
  
                        <Button
                            variant="contained"
                            color="primary"
                            // component={Link} to="/projectlist"
                            type='submit'
                        >
                            Connect Jira
                        </Button>
                        {loading && (
        <div style={loaderStyle}>
          <RingLoader size={35} color={"#05b2bd"} loading={loading} />
        </div>
      )}
                    </Grid>
                </Grid>
        </form>
        <ToastContainer />
        {/* {loading && (
        <div className="loader">
          <ClipLoader size={35} color={"#123abc"} loading={loading} />
        </div>
      )} */}
  </Box>
    )
}