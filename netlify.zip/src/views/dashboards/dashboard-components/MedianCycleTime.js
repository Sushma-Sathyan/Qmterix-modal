// MedianCycleTime.js
import React from 'react';
import { Card, CardContent, Typography } from '@mui/material';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
import { Box, Button, Stack } from '@mui/material';
import InfoIcon from '@mui/icons-material/Info';

const data = [
    { name: 'Day 1', value: 10, fill: '#444444' },
    { name: 'Day 2', value: 16, fill: '#444444' },
    { name: 'Day 3', value: 11, fill: '#444444' },
    { name: 'Day 4', value: 17, fill: '#444444' },
    { name: 'Day 5', value: 19, fill: '#444444' },
    { name: 'Day 6', value: 18, fill: '#444444' },
    { name: 'Day 7', value: 20, fill: '#00C49F' }, // Only the last bar colored
];

const MedianCycleTime = () => (
    <Card elevation={0}
    sx={{
      position: 'relative',
      backgroundColor: (theme) => `${theme.palette.mode === 'dark' ? '#32363e' : ''}`,
      '&:before': {
        content: `""`,
        position: 'absolute',
        width: '100%',
        height: '100%',
        backgroundRepeat: 'no-repeat',
        backgroundSize: '45%',
        transform: (theme) => `${theme.direction === 'rtl' ? '' : 'unset'}`,
        backgroundPosition: {
          xs: 'top 0px right -9px',
        },
      },
      borderWidth: '0px',
      margin: '10px',
      padding: '5px',
      borderRadius: '10px'
    }}>
      <CardContent>
        <Box display="flex" alignItems="center">
            <Typography variant="subtitle1" sx={{ display: 'inline-flex', alignItems: 'center' }}>
                MEDIAN CYCLE TIME
                <InfoIcon fontSize="medium" sx={{ marginLeft: '4px' }} />
            </Typography>
        </Box>
        <Box display="flex" justifyContent="space-between" alignItems="center">
            <Box >
                <Box display="flex" alignItems="baseline">
                    <Typography variant="h1" component="h1" style={{ display: 'inline-flex', alignItems: 'center', fontWeight: 'bold', fontSize: '3rem' }}>7.4</Typography>
                    <Typography variant="body1" style={{ marginLeft: '5px' }}>
                    {'\u2192'} 0%
                    </Typography>
                </Box>
                <Typography variant="body2" style={{ color: '#A0A0A0', marginTop: '-10px' }}>Days</Typography>
            </Box>
            
            <ResponsiveContainer width="50%" height={80}>
                <BarChart data={data} barCategoryGap={1}>
                    <XAxis dataKey="name" hide />
                    <YAxis hide />
                    <Bar dataKey="value" barSize={10} /> {/* Set barSize for thinner bars */}
                </BarChart>
            </ResponsiveContainer>
        </Box>
        </CardContent>
    </Card>
  );

export default MedianCycleTime;
