import { Grid } from '@mui/material';
import Breadcrumb from '../../../layouts/full-layout/breadcrumb/Breadcrumb';
import PageContainer from '../../../components/container/PageContainer';
import CustomTextField from '../../../components/forms/custom-elements/CustomTextField';
import CustomFormLabel from '../../../components/forms/custom-elements/CustomFormLabel';
import { Button } from '@mui/material';
import * as yup from "yup"
import { useState } from 'react';
import { useFormik } from 'formik';
import { useNavigate } from 'react-router';
const BCrumb = [
  {
    to: '/dashboards/dashboard',
    title: 'Home',
  },
  {
    title: 'Add New User',
  },
];

const AddUser = () => {
    const navigate = useNavigate();
    const [initialValues, setInitialValues] = useState({
    user: "",
    email:"",
    projectName: "",
    users: ""
  })
  const validationSchema = yup.object({
    user: yup.string().required("User Name is required"),
    email: yup.string().email('Invalid email').required('Email is required'),
    projectName: yup.string().required("Project Name is required"),
    users: yup.string().required("Users is required"),
  });
  const onCancel = () => {
    navigate('/users')
  }
  const formik = useFormik({
    initialValues: initialValues,
    enableReinitialize: true,
    validationSchema: validationSchema,
    onSubmit: (values) => {
    },
  });
  return (
    <form onSubmit={formik.handleSubmit}>
      <PageContainer title="Add NewUser" description="Org Handle
    Profile at QMetrix.com/org/<Org Handle>. Must be unique. Max. 38 characters. Alphanumeric and special character - only.">
        {/* breadcrumb */}
        <Breadcrumb title="Add New User" items={BCrumb} />
        {/* end breadcrumb */}
        <Grid container spacing={2}>
          <Grid item xs={4}>
            <CustomFormLabel htmlFor="User">User</CustomFormLabel>
            <CustomTextField
              id="user"
              placeholder="Enter User"
              name="user"
              variant="outlined"
              fullWidth
              size="small"
              value={formik.values.user}
              onChange={formik.handleChange}
              error={formik.touched.user && Boolean(formik.errors.user)}
              helperText={formik.touched.user && formik.errors.user}
            />
          </Grid>
          <Grid item xs={4}>
            <CustomFormLabel htmlFor="Email">Email</CustomFormLabel>
            <CustomTextField
              id="email"
              placeholder="Enter Email"
              name="email"
              variant="outlined"
              fullWidth
              size="small"
              value={formik.values.email}
              onChange={formik.handleChange}
              error={formik.touched.email && Boolean(formik.errors.email)}
              helperText={formik.touched.email && formik.errors.email}
            />
          </Grid>
          <Grid item xs={4}>
          </Grid>
          <Grid item xs={4}>
            <CustomFormLabel htmlFor="Project Name">Project Name</CustomFormLabel>
            <CustomTextField
              id="projectName"
              placeholder="Project Name"
              variant="outlined"
              name="projectName"
              fullWidth
              size="small"
              value={formik.values.projectName}
              onChange={formik.handleChange}
              error={formik.touched.projectName && Boolean(formik.errors.projectName)}
              helperText={formik.touched.projectName && formik.errors.projectName}
            />
          </Grid>
          <Grid item xs={4}>
            <CustomFormLabel htmlFor="Users">Users</CustomFormLabel>
            <CustomTextField
              id="users"
              placeholder="Users"
              variant="outlined"
              name="users"
              fullWidth
              multiline={true}
              rows={4}
              size="small"
              value={formik.values.users}
              onChange={formik.handleChange}
              // onBlur={formik.handleBlur}
              error={formik.touched.users && Boolean(formik.errors.users)}
              helperText={formik.touched.users && formik.errors.users}
            />
          </Grid>
          <Grid item xs={4}>
          </Grid>
          <Grid item xs={5}>
          </Grid>
          <Grid item  xs={2}>
            <Button
              variant="contained"
              color="primary"
              type='submit'
            >
              Save Changes
            </Button>
          </Grid>
          <Grid item  xs={1}>
            <Button
              variant="contained"
              color="inherit"
              type=''
              onClick={onCancel}
            >
              Cancel
            </Button>
          </Grid>
        </Grid>
      </PageContainer>
    </form>
  );
};

export default AddUser;
