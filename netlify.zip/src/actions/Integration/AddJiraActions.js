import api from "../../utils/api";
import { FETCH_ADD_JIRA_DETAILS_SUCCESS, FETCH_ADD_JIRA_DETAILS_FAILURE } from '../types';

export default async function addJiraDetails(dispatch,payload) {
    try {
      const response = await api.post('/master/add/jiraprojecttotenant',payload);
      dispatch({type:FETCH_ADD_JIRA_DETAILS_SUCCESS,payload:response.data})
      return response.data
    } catch (error) {
      dispatch({type:FETCH_ADD_JIRA_DETAILS_FAILURE,payload:error.message})
    }
  }