//-----------------Action Types --------------------------

//----------------- Login -------------------------------
export const FETCH_LOGIN_REQUEST ='FETCH_LOGIN_REQUEST';
export const FETCH_LOGIN_SUCCESS = 'FETCH_LOGIN_SUCCESS';
export const FETCH_LOGIN_FAILURE = 'FETCH_LOGIN_FAILURE';

// -----------------Register -----------------------------

export const FETCH_REGISTER_REQUEST ='FETCH_REGISTER_REQUEST';
export const FETCH_REGISTER_SUCCESS = 'FETCH_REGISTER_SUCCESS';
export const FETCH_REGISTER_FAILURE = 'FETCH_REGISTER_FAILURE';

// -----------------reset-password -----------------------------

export const FETCH_RESET_PASSWORD_REQUEST ='FETCH_RESET_PASSWORD_REQUEST';
export const FETCH_RESET_PASSWORD_SUCCESS = 'FETCH_RESET_PASSWORD_SUCCESS';
export const FETCH_RESET_PASSWORD_FAILURE = 'FETCH_RESET_PASSWORD_FAILURE';

//----------------- forgot-password -------------------------------
export const FETCH_FORGOT_PASSWORD_REQUEST ='FETCH_FORGOT_PASSWORD_REQUEST';
export const FETCH_FORGOT_PASSWORD_SUCCESS = 'FETCH_FORGOT_PASSWORD_SUCCESS';
export const FETCH_FORGOT_PASSWORD_FAILURE = 'FETCH_FORGOT_PASSWORD_FAILURE';

//----------------- JIRA Connection -------------------------------
export const FETCH_JIRA_DETAILS_REQUEST = 'FETCH_JIRA_DETAILS_REQUEST';
export const FETCH_JIRA_DETAILS_SUCCESS = 'FETCH_JIRA_DETAILS_SUCCESS';
export const FETCH_JIRA_DETAILS_FAILURE = 'FETCH_JIRA_DETAILS_FAILURE';

//----------------- JIRA ADD Connection -------------------------------
export const FETCH_ADD_JIRA_DETAILS_REQUEST = 'FETCH_ADD_JIRA_DETAILS_REQUEST';
export const FETCH_ADD_JIRA_DETAILS_SUCCESS = 'FETCH_ADD_JIRA_DETAILS_SUCCESS';
export const FETCH_ADD_JIRA_DETAILS_FAILURE = 'FETCH_ADD_JIRA_DETAILS_FAILURE';